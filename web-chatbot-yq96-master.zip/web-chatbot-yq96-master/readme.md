# 应用说明

```bash
├── index.js # 入口文件，包含了调用百炼大模型应用，并暴露为 HTTP /chat 路由访问的代码。
└── public
    ├── assets # 示例网站的静态资源。
    └── index.html # 示例网站代码。
```
